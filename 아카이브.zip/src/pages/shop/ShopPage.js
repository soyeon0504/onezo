import React from 'react'

const ShopPage = () => {
  return (
    <div>ShopPage</div>
  )
}

export default ShopPage