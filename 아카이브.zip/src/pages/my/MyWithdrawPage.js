import React from 'react'

const MyWithdrawPage = () => {
  return (
    <div>MyWithdrawPage</div>
  )
}

export default MyWithdrawPage