import React from 'react'

const MyOrderStatePage = () => {
  return (
    <div>MyOrderStatePage</div>
  )
}

export default MyOrderStatePage