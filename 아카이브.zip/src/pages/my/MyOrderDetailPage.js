import React from 'react'

const MyOrderDetailPage = () => {
  return (
    <div>MyOrderDetailPage</div>
  )
}

export default MyOrderDetailPage