import React from 'react'

const MyInfoData = {
  id: "onezo123",
  name:"김그린",
  nick:"그린컴퓨터",
  phone:"01012341234",
}

const MyInfoPage = () => {
  return (
    <div>MyInfoPage</div>
  )
}

export default MyInfoPage