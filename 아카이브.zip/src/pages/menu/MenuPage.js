import React from 'react'
import Layout from '../../layouts/Layout'

const MenuPage = () => {
  return (
    <div>
        <Layout />
        <div>sfkldsjflkdsjkl</div>
    </div>
  )
}

export default MenuPage