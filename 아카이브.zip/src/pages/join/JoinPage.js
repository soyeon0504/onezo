import React from 'react'

const JoinPage = () => {
  return (
    <div>JoinPage</div>
  )
}

export default JoinPage