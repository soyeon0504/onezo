import React from 'react'

const PaymentPage = () => {
  return (
    <div>PaymentPage</div>
  )
}

export default PaymentPage