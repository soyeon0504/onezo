import React, { Suspense, lazy } from 'react'
import { createBrowserRouter } from 'react-router-dom'
import Loading from '../components/loading/Loading'

const MainPage = lazy(()=>import("../pages/main/MainPage"))

const router = createBrowserRouter([

  {path:"/",
element:(
  <Suspense fallback={<Loading/>}>
    <MainPage />
  </Suspense>
)}
])

export default root