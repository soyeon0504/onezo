import React from 'react'

const useMemo = () => {
  return (
    <div>useMemo</div>
  )
}

export default useMemo